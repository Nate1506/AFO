#!/usr/bin/env node
// Hermes support is a real plugin, not just copied rules: the repo root must be
// installable with `hermes plugins install owner/repo`, register bundled skills,
// inject active mode context, and expose slash commands.

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');
const { filterSkillBodyForMode } = require('../hooks/ponytail-instructions');

const commands = ['ponytail', 'ponytail-review', 'ponytail-audit', 'ponytail-debt', 'ponytail-gain', 'ponytail-help'];
const skillCommands = commands.filter((name) => name !== 'ponytail');

const root = path.join(__dirname, '..');

// ponytail: probe once; on Windows `python3` is the Store-alias stub that fails
// even when Python is installed, so fall back to `python` (mirrors benchmarks/correctness.js).
let pythonCmd;
function pythonExe() {
  if (pythonCmd) return pythonCmd;
  for (const cmd of ['python3', 'python']) {
    if (spawnSync(cmd, ['-c', 'import sys'], { encoding: 'utf8' }).status === 0) {
      return (pythonCmd = cmd);
    }
  }
  return (pythonCmd = 'python3');
}

function python(script, env = {}) {
  const result = spawnSync(pythonExe(), ['-c', script], {
    cwd: root,
    // Isolate from the developer's own ~/.config/ponytail and PONYTAIL_DEFAULT_MODE.
    env: {
      ...process.env,
      PONYTAIL_DEFAULT_MODE: '',
      XDG_CONFIG_HOME: fs.mkdtempSync(path.join(os.tmpdir(), 'ponytail-config-')),
      ...env,
    },
    encoding: 'utf8',
  });
  if (result.status !== 0) {
    throw new Error(`python failed\nSTDOUT:\n${result.stdout}\nSTDERR:\n${result.stderr}`);
  }
  return result.stdout.trim();
}

test('Hermes plugin manifest matches runtime skills, hooks, commands, and package version', () => {
  const manifestPath = path.join(root, 'plugin.yaml');
  assert.ok(fs.existsSync(manifestPath), 'missing root plugin.yaml');
  const manifest = fs.readFileSync(manifestPath, 'utf8');
  const packageJson = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
  const skillDirs = fs.readdirSync(path.join(root, 'skills'))
    .filter((name) => fs.existsSync(path.join(root, 'skills', name, 'SKILL.md')))
    .sort();

  assert.match(manifest, /^name:\s*ponytail$/m);
  assert.match(manifest, new RegExp(`^version:\\s*${packageJson.version}$`, 'm'));
  assert.match(manifest, new RegExp(`^author:\\s*${packageJson.author.name}$`, 'm'));
  assert.deepEqual(commands.filter((name) => manifest.includes(`  - ${name}`)), commands);
  assert.deepEqual(skillDirs.filter((name) => manifest.includes(`  - ${name}`)), skillDirs);
  assert.match(manifest, /pre_llm_call/);
  assert.match(manifest, /pre_gateway_dispatch/);
});

test('Hermes plugin registers every shipped skill under the ponytail namespace', () => {
  const output = python(String.raw`
import importlib.util, json, pathlib
spec = importlib.util.spec_from_file_location('ponytail_hermes_plugin', '__init__.py')
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
class Ctx:
    def __init__(self):
        self.skills = []
        self.hooks = []
        self.commands = []
    def register_skill(self, name, path):
        self.skills.append((name, pathlib.Path(path).as_posix()))
    def register_hook(self, name, handler):
        self.hooks.append(name)
    def register_command(self, name, handler, description='', args_hint=''):
        self.commands.append(name)
ctx = Ctx()
mod.register(ctx)
print(json.dumps({'skills': ctx.skills, 'hooks': ctx.hooks, 'commands': ctx.commands}, sort_keys=True))
`);
  const data = JSON.parse(output);
  assert.deepEqual(data.skills.map(([name]) => name).sort(), [
    'ponytail',
    'ponytail-audit',
    'ponytail-debt',
    'ponytail-gain',
    'ponytail-help',
    'ponytail-review',
  ]);
  assert.ok(data.skills.every(([, skillPath]) => skillPath.endsWith('/SKILL.md')));
  assert.ok(data.hooks.includes('pre_llm_call'));
  assert.ok(data.commands.includes('ponytail'));
  assert.ok(data.commands.includes('ponytail-review'));
});

test('Hermes plugin builds mode-aware injected context from the canonical skill', () => {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'ponytail-config-'));
  const output = python(String.raw`
import importlib.util, json
spec = importlib.util.spec_from_file_location('ponytail_hermes_plugin', '__init__.py')
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
ctx = mod.build_injected_context('ultra')
print(json.dumps({'ctx': ctx}))
`, { XDG_CONFIG_HOME: tmp });
  const { ctx } = JSON.parse(output);

  assert.match(ctx, /PONYTAIL MODE ACTIVE — level: ultra/);
  assert.match(ctx, /The best\s+code is the code never written/);
  assert.match(ctx, /ultra/i);
  assert.doesNotMatch(ctx, /^---/);
  assert.doesNotMatch(ctx, /\|\s*\*\*Lite\*\*/i);
});

test('Hermes mode config respects env, config file, off, and invalid command behavior', () => {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'ponytail-config-'));
  fs.mkdirSync(path.join(tmp, 'ponytail'), { recursive: true });
  fs.writeFileSync(path.join(tmp, 'ponytail', 'config.json'), JSON.stringify({ defaultMode: 'lite' }));
  const output = python(String.raw`
import importlib.util, json
spec = importlib.util.spec_from_file_location('ponytail_hermes_plugin', '__init__.py')
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
class Ctx:
    def __init__(self): self.commands = {}
    def register_skill(self, name, path): pass
    def register_hook(self, name, handler): pass
    def register_command(self, name, handler, description='', args_hint=''):
        self.commands[name] = handler
ctx = Ctx()
mod.register(ctx)
status_before = ctx.commands['ponytail']('')
invalid = ctx.commands['ponytail']('maximum')
status_after = ctx.commands['ponytail']('')
print(json.dumps({
    'default': mod.build_injected_context(None),
    'off': mod.build_injected_context('off'),
    'status_before': status_before,
    'invalid': invalid,
    'status_after': status_after,
}))
`, { XDG_CONFIG_HOME: tmp, PONYTAIL_DEFAULT_MODE: 'ultra' });
  const data = JSON.parse(output);
  assert.match(data.default, /level: ultra/);
  assert.equal(data.off, '');
  assert.match(data.status_before, /Ponytail mode: ultra/);
  assert.match(data.invalid, /Usage:/);
  assert.match(data.status_after, /Ponytail mode: ultra/);
});

test('Hermes honors plain and BOM-prefixed default-mode config before LLM calls', (t) => {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'ponytail-config-'));
  t.after(() => fs.rmSync(tmp, { recursive: true, force: true }));
  fs.mkdirSync(path.join(tmp, 'ponytail'));
  for (const prefix of ['', '\uFEFF']) {
    for (const mode of ['lite', 'off']) {
      fs.writeFileSync(path.join(tmp, 'ponytail', 'config.json'), prefix + JSON.stringify({ defaultMode: mode }));
      const output = python(String.raw`
import importlib.util, json
spec = importlib.util.spec_from_file_location('ponytail_hermes_plugin', '__init__.py')
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
print(json.dumps(mod._pre_llm_call()))
`, { XDG_CONFIG_HOME: tmp, PONYTAIL_DEFAULT_MODE: '' });
      const data = JSON.parse(output);
      if (mode === 'off') assert.equal(data, null);
      else assert.match(data.context, /PONYTAIL MODE ACTIVE — level: lite/);
    }
  }
});

test('Hermes treats review as a command, never a level', () => {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'ponytail-review-default-'));
  fs.mkdirSync(path.join(tmp, 'ponytail'), { recursive: true });
  fs.writeFileSync(path.join(tmp, 'ponytail', 'config.json'), JSON.stringify({ defaultMode: 'review' }));
  const output = python(String.raw`
import importlib.util, json, os
spec = importlib.util.spec_from_file_location('ponytail_hermes_plugin', '__init__.py')
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
env_default = mod.build_injected_context(None)
del os.environ['PONYTAIL_DEFAULT_MODE']
file_default = mod.build_injected_context(None)
explicit_review = mod.build_injected_context('review')
print(json.dumps({
    'env_default': env_default,
    'file_default': file_default,
    'explicit_review': explicit_review,
}))
`, { XDG_CONFIG_HOME: tmp, PONYTAIL_DEFAULT_MODE: 'review' });
  const data = JSON.parse(output);
  assert.match(data.env_default, /PONYTAIL MODE ACTIVE — level: full/);
  assert.match(data.file_default, /PONYTAIL MODE ACTIVE — level: full/);
  assert.match(data.explicit_review, /PONYTAIL MODE ACTIVE — level: full/);
});

test('Hermes /ponytail command changes mode and pre_llm_call injects current context', () => {
  const output = python(String.raw`
import importlib.util, json
spec = importlib.util.spec_from_file_location('ponytail_hermes_plugin', '__init__.py')
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
class Ctx:
    def __init__(self):
        self.hooks = {}
        self.commands = {}
    def register_skill(self, name, path): pass
    def register_hook(self, name, handler): self.hooks[name] = handler
    def register_command(self, name, handler, description='', args_hint=''):
        self.commands[name] = handler
ctx = Ctx()
mod.register(ctx)
message = ctx.commands['ponytail']('ultra')
injected = ctx.hooks['pre_llm_call'](session_id='s1', user_message='build it', conversation_history=[], is_first_turn=False, model='m', platform='cli')
print(json.dumps({'message': message, 'context': injected['context']}))
`);
  const data = JSON.parse(output);
  assert.match(data.message, /ultra/);
  assert.match(data.context, /PONYTAIL MODE ACTIVE — level: ultra/);
});

test('Hermes pre_llm_call does not append the same ruleset to every persisted turn', () => {
  const output = python(String.raw`
import importlib.util, json
spec = importlib.util.spec_from_file_location('ponytail_hermes_plugin', '__init__.py')
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
first = mod._pre_llm_call(conversation_history=[])
history = [{
    'role': 'user',
    'content': 'first task',
    'api_content': 'first task\\n\\n' + first['context'],
}]
second = mod._pre_llm_call(conversation_history=history)
mod._current_mode = 'ultra'
switched = mod._pre_llm_call(conversation_history=history)
history.append({
    'role': 'user',
    'content': 'second task',
    'api_content': 'second task\\n\\n' + switched['context'],
})
after_switch = mod._pre_llm_call(conversation_history=history)
print(json.dumps({'first': first, 'second': second, 'switched': switched, 'after_switch': after_switch}))
`);
  const data = JSON.parse(output);
  assert.match(data.first.context, /PONYTAIL MODE ACTIVE — level: full/);
  assert.equal(data.second, null);
  assert.match(data.switched.context, /PONYTAIL MODE ACTIVE — level: ultra/);
  assert.equal(data.after_switch, null);
});

test('Hermes /ponytail off reaches the model once, and a later level re-injects the ruleset', () => {
  // The ruleset from the first turn is replayed from api_content on every later
  // turn, and the command's reply goes to the user only, so off must be injected.
  const output = python(String.raw`
import importlib.util, json
spec = importlib.util.spec_from_file_location('ponytail_hermes_plugin', '__init__.py')
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
first = mod._pre_llm_call(conversation_history=[])
history = [{
    'role': 'user',
    'content': 'first task',
    'api_content': 'first task\\n\\n' + first['context'],
}]
mod._handle_mode_command('off')
nothing_persisted = mod._pre_llm_call(conversation_history=[])
off = mod._pre_llm_call(conversation_history=history)
history.append({
    'role': 'user',
    'content': 'second task',
    'api_content': 'second task\\n\\nPONYTAIL MODE OFF',
})
still_off = mod._pre_llm_call(conversation_history=history)
mod._handle_mode_command('full')
back_on = mod._pre_llm_call(conversation_history=history)
print(json.dumps({'nothing_persisted': nothing_persisted, 'off': off, 'still_off': still_off, 'back_on': back_on}))
`);
  const data = JSON.parse(output);
  assert.equal(data.nothing_persisted, null);
  assert.deepEqual(data.off, { context: 'PONYTAIL MODE OFF' });
  assert.equal(data.still_off, null);
  assert.match(data.back_on.context, /PONYTAIL MODE ACTIVE — level: full/);
});

test('Hermes gateway rewrite respects slash access denial', () => {
  const output = python(String.raw`
import importlib.util, json
spec = importlib.util.spec_from_file_location('ponytail_hermes_plugin', '__init__.py')
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
class Source:
    platform = None
    chat_id = 'c1'
    user_id = 'u1'
class Event:
    text = '/ponytail-review src/app.js'
    source = Source()
class Gateway:
    def _check_slash_access(self, source, command):
        return 'denied'
result = mod.rewrite_gateway_command(event=Event(), gateway=Gateway())
print(json.dumps(result))
`);
  assert.equal(output, 'null');
});

test('Hermes bare /ponytail switches an off session on and only reports a running level (#639)', () => {
  const output = python(String.raw`
import importlib.util, json
spec = importlib.util.spec_from_file_location('ponytail_hermes_plugin', '__init__.py')
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
mod._current_mode = 'ultra'
running = mod._handle_mode_command('')
kept = mod._current_mode
mod._current_mode = 'off'
switched = mod._handle_mode_command('')
print(json.dumps([running, kept, switched, mod._current_mode]))
`);
  const [running, kept, switched, after] = JSON.parse(output);
  assert.match(running, /Ponytail mode: ultra/);
  assert.equal(kept, 'ultra');
  assert.match(switched, /set to full/);
  assert.equal(after, 'full');
});

test('Hermes gateway rewrite preserves every skill command and ignores unrelated text', () => {
  const output = python(String.raw`
import importlib.util, json
spec = importlib.util.spec_from_file_location('ponytail_hermes_plugin', '__init__.py')
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
class Event:
    def __init__(self, text): self.text = text
cases = {}
for text in ['/ponytail-review x', '/ponytail_audit repo', '/ponytail-debt', '/ponytail-help', '/status', 'hello']:
    cases[text] = mod.rewrite_gateway_command(event=Event(text))
print(json.dumps(cases, sort_keys=True))
`);
  const data = JSON.parse(output);
  assert.match(data['/ponytail-review x'].text, /ponytail-review/);
  assert.match(data['/ponytail_audit repo'].text, /ponytail-audit/);
  assert.match(data['/ponytail_audit repo'].text, /repo/);
  assert.match(data['/ponytail-debt'].text, /ponytail-debt/);
  assert.match(data['/ponytail-help'].text, /ponytail-help/);
  assert.equal(data['/status'], null);
  assert.equal(data.hello, null);
});

test('Hermes mode filter does not drop a rule bullet whose label matches a mode name', () => {
  // Regression for the Hermes side of #571: a rule bullet shaped "- Full: ..."
  // has the same "label: text" shape as a worked example, but isn't one — it
  // must survive in every mode. Only the quoted `- lite: "..."`-style bullets
  // are real per-mode examples. hooks/ponytail-instructions.js already guards
  // against this; the Hermes plugin filter had drifted and lost the same guard.
  const output = python(String.raw`
import importlib.util, json
spec = importlib.util.spec_from_file_location('ponytail_hermes_plugin', '__init__.py')
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
body = (
    "- Full: do not confuse this rule label with the mode name.\n"
    "- Lite: same risk, this is a real rule bullet.\n"
    '- lite: "real worked example"\n'
    '- ultra: "real worked example"'
)
print(json.dumps({'filtered': mod._filter_skill_body_for_mode(body, 'ultra')}))
`);
  const { filtered } = JSON.parse(output);
  assert.ok(filtered.includes('Full: do not confuse'), 'an unquoted rule bullet must not be treated as a mode example');
  assert.ok(filtered.includes('Lite: same risk'), 'an unquoted rule bullet must not be treated as a mode example');
  assert.ok(!filtered.includes('- lite:'), 'the real quoted lite example must still be filtered out in ultra mode');
  assert.ok(filtered.includes('ultra: "real worked example"'));
});

test('Hermes mode filter stays in lockstep with the JS filter on the real skill body', () => {
  // The two filters are independent ports of the same contract (one shared
  // skill file, every host adapter trims it the same way). Diff them directly
  // on skills/ponytail/SKILL.md instead of trusting the two implementations to
  // stay in sync by hand.
  const body = fs.readFileSync(path.join(root, 'skills', 'ponytail', 'SKILL.md'), 'utf8');
  for (const mode of ['lite', 'full', 'ultra']) {
    const jsFiltered = filterSkillBodyForMode(body, mode);
    const pyFiltered = python(String.raw`
import importlib.util, json
spec = importlib.util.spec_from_file_location('ponytail_hermes_plugin', '__init__.py')
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
body = open('skills/ponytail/SKILL.md', encoding='utf-8').read()
print(json.dumps(mod._filter_skill_body_for_mode(body, '${mode}')))
`);
    assert.equal(JSON.parse(pyFiltered), jsFiltered, `filters diverge for mode "${mode}"`);
  }
});
